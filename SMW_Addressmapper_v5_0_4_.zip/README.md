# SMW_Addressmapper
Allows the user to view a list of used address (RAM, for example) in an easier format. After a list is supplied, it will output the formatted list, in ascending/descending order, and also lists any overlapping addresses and any gaps in between.
